import { Component, OnInit } from '@angular/core';
import { RegistrationService } from '../Services/registration.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent{

  users:any;
  constructor(private registerService:RegistrationService) { 
    this.registerService.GetCustomers().subscribe(i=>
      {
        this.users=i;
        console.log(i);
      })
  
  }


}
