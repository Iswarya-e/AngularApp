export interface IProduct
{
    productId: number;
    imageUrl: string;
    productCode:string;
    productName:string;
    price:number;
    starRating:number;
}