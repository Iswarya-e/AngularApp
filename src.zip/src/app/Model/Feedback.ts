export class Feedback{
        FeedbackId:number;
        FeedbackGiven:string;
        FeedbackBy:string;
        FeedbackDate:Date;
  results: any;
}