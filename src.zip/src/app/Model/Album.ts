export class Album{
    userId:number;
    id:number;
    title:string;
}