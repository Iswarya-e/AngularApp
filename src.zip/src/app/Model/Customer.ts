export class Customer{
        userId:number;
        userName:string;
        password:string;
        age:number ;
        email:string;
        phoneNumber:string;;
        dob:Date;
        userImage:string;
        filename:string;
        fileType: string;
        fileAsBase64: string;
}