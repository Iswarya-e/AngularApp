import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { IProduct } from '../Interface/IProduct';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  productUrl="./assets/Product.json";
  constructor(private http:HttpClient) { }
 
  getProductData():Observable<IProduct[]>{
    return this.http.get<IProduct[]>(this.productUrl).pipe(catchError(this.handleError))
  }

  getProductDatabyId(id:any):Observable<IProduct>{
    return this.http.get<IProduct>(this.productUrl+"?productId="+id)

  }
  handleError(error:any){
    let errorMessage='';
    if(error.error instanceof ErrorEvent){
      errorMessage=`Error:${error.error.message}`;
    }
    else{
      errorMessage=`Error Code:${error.status}\nMessage:${error.message}`
    }
    return throwError(errorMessage)
  }
}
