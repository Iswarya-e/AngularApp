import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProduct } from '../Interface/IProduct';
import { ProductsService } from '../Services/products.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers: [ProductsService]

})
export class ProductComponent{


  products:any;
  imageWidth:number=100;
  imageMargin:number=10;


  constructor(private prodService:ProductsService,private router:Router){
    let a=localStorage.getItem('uname');
    if(!(typeof a != 'undefined' && a)){
      this.router.navigate(["Login"])
    }
    this.prodService.getProductData().subscribe(data =>
      {this.products=data;});
  }

   
  }


