import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { FeedbackService } from '../Services/feedback.service';

@Component({
  selector: 'app-create-feedback',
  templateUrl: './create-feedback.component.html',
  styleUrls: ['./create-feedback.component.css']
})
export class CreateFeedbackComponent  {

  feedbackDate:Date;
  mygroup:FormGroup;
  constructor(private myBuilder:FormBuilder,private _router:Router,private feedbackService:FeedbackService,private router:Router) { 
   
    let a=localStorage.getItem('uname');
    if(!(typeof a != 'undefined' && a)){
      this.router.navigate(["Login"])
    }
    this.mygroup=this.myBuilder.group({
      'FeedbackId':[],
      'FeedbackGiven':'',
      'FeedbackBy':'',
      'FeedbackDate':new Date()
    })
  }
 
  SaveFeedback(){

    this.feedbackService.SaveFeedBack(this.mygroup,).subscribe(data=>{
      console.log("Customer created successfully");
      alert("Customer created successfully") ;   
  },
  Error=>{
    console.log("Error");
    alert("Error") 
  });


      //  localStorage.setItem('uname',this.mygroup.get('username').value)
      //  localStorage.setItem('pword',this.mygroup.get('password').value)
      //  this._router.navigate(["Login"])
    }

}
